<?php 

echo "isi halaman2 </br>";
echo isihalaman;

?>