<?php echo $_header; ?>
<?php echo $_topbar; ?>
<?php echo $_sidebar; ?>
<?php echo $_content; ?>
<?php echo $_sidebar_info; ?>
<?php echo $_footer; ?>