  <!-- Main Footer -->
  <footer class="main-footer text-sm d-print-none">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Siak Versi 2.0
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2020 <a href="" style="color: teal">YAYASAN PAGUWARMAS</a></strong> Maos-Cilacap. All rights reserved.
  </footer>
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->

  <!-- jQuery -->
  <!-- jQuery -->
  <script src="<?= base_url('assets/') ?>plugins/jquery/jquery.min.js"></script>
  <!-- <script src="dist/js/jquery-3.4.1.min.js"></script> -->
  <!-- jQuery UI 1.11.4 -->
  <script src="<?= base_url('assets/') ?>plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="<?= base_url('assets/') ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- ChartJS -->
  <!-- <script src="<? //base_url('assets/') 
                    ?>plugins/chart.js/Chart.min.js"></script> -->
  <!-- Sparkline -->
  <!-- <script src="<? //base_url('assets/') 
                    ?>plugins/sparklines/sparkline.js"></script> -->
  <!-- JQVMap -->
  <!-- <script src="<? //base_url('assets/') 
                    ?>plugins/jqvmap/jquery.vmap.min.js"></script> -->
  <!-- <script src="<? //base_url('assets/') 
                    ?>plugins/jqvmap/maps/jquery.vmap.usa.js"></script> -->
  <!-- jQuery Knob Chart -->
  <!-- <script src="<? //base_url('assets/') 
                    ?>plugins/jquery-knob/jquery.knob.min.js"></script> -->
  <!-- daterangepicker -->
  <script src="<?= base_url('assets/') ?>plugins/moment/moment.min.js"></script>
  <script src="<?= base_url('assets/') ?>plugins/daterangepicker/daterangepicker.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="<?= base_url('assets/') ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <!-- <script src="<? // base_url('assets/') 
                    ?>plugins/summernote/summernote-bs4.min.js"></script> -->
  <!-- overlayScrollbars -->
  <script src="<?= base_url('assets/') ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- SweetAlert2 -->
  <script src="<?= base_url('assets/') ?>plugins/sweetalert2/sweetalert2.min.js"></script>
  <!-- Toastr -->
  <script src="<?= base_url('assets/') ?>plugins/toastr/toastr.min.js"></script>
  <!-- DataTables -->
  <script src="<?= base_url('assets/') ?>plugins/datatables/jquery.dataTables.js"></script>
  <script src="<?= base_url('assets/') ?>plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.flash.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.html5.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.print.min.js"></script> -->
  <!-- AdminLTE App -->
  <script src="<?= base_url('assets/') ?>dist/js/adminlte.js"></script>
  <script src="<?= base_url('assets/') ?>dist/js/jquery.inputmask.bundle.js"></script>
  <script src="<?= base_url('assets/') ?>dist/js/siak.js"></script>
  <script src="<?= base_url('assets/') ?>dist/js/tes.js"></script>
  <script>
    // $('#tabel1').DataTable({
    //    "paging": true,
    //    "lengthChange": true,
    //    "searching": true,
    //    "ordering": true,
    //    "info": true,
    //    "autoWidth": false,
    //  })

    // $(document).ready(function(){
    //     $('#tabel1').DataTable({
    //       "paging": true,
    //       "lengthChange": true,
    //       "searching": true,
    //       "ordering": true,
    //       "info": true,
    //       "autoWidth": false,
    //       "ordering": false
    // "columnDefs":[{ "orderable": false, "targets": [0,3] }],
    //     })

    //     $('#sidebar-menu').on('hover', '.nav-item', function (e) {
    //       $(this).$('[data-toggle="tooltip"]').tooltip()
    //     })

    // })
  </script>

  </body>

  </html>